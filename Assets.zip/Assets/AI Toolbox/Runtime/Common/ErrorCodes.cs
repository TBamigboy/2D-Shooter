﻿namespace AiToolbox {
public enum ErrorCodes {
    MaxTokensExceeded = 0,
    ThrottleExceeded = 1,
    RemoteConfigConnectionFailure = 2,
    RemoteConfigKeyNotFound = 3,
    Unknown = 4,
}
}