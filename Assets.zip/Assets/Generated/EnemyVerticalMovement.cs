using UnityEngine;

public class EnemyVerticalMovement : MonoBehaviour
{
    [Tooltip("Speed at which the enemy moves up and down.")]
    [SerializeField] private float speed = 2.0f;

    [Tooltip("Maximum distance the enemy can move up and down from its starting position.")]
    [SerializeField] private float maxDistance = 3.0f;

    private Vector3 startPosition;
    private bool movingUp = true;

    private void Start()
    {
        startPosition = transform.position;
    }

    private void Update()
    {
        float step = speed * Time.deltaTime;
        if (movingUp)
        {
            transform.position += Vector3.up * step;
            if (transform.position.y >= startPosition.y + maxDistance)
            {
                movingUp = false;
            }
        }
        else
        {
            transform.position -= Vector3.up * step;
            if (transform.position.y <= startPosition.y - maxDistance)
            {
                movingUp = true;
            }
        }
    }
}