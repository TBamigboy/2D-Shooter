using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScipt : MonoBehaviour
{
    [Tooltip("Speed at which the enemy moves up and down.")]
    [SerializeField] private float moveSpeed = 2.0f;

    [Tooltip("Maximum distance the enemy can move up and down from its starting position.")]
    [SerializeField] private float moveDistance = 3.0f;

    private Vector3 startPosition;
    private bool movingUp = true;

    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        float newY = transform.position.y + (movingUp ? moveSpeed : -moveSpeed) * Time.deltaTime;
        float distanceFromStart = newY - startPosition.y;

        if (Mathf.Abs(distanceFromStart) >= moveDistance)
        {
            movingUp = !movingUp;
            newY = startPosition.y + (movingUp ? moveDistance : -moveDistance);
        }

        transform.position = new Vector3(transform.position.x, newY, transform.position.z);
    }
}