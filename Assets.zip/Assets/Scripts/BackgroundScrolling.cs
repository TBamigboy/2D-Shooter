using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundScroll : MonoBehaviour
{
    public float scrollSpeed = 0.5f;  // Controls how fast the background scrolls
    private Vector3 startPosition;    // Stores the starting position of the background

    void Start()
    {
        // Capture the initial position of the background
        startPosition = transform.position;
    }

    void Update()
    {
        // Move the background horizontally based on time and scrollSpeed
        float newPosition = Mathf.Repeat(Time.time * scrollSpeed, 20); // 20 is the background width
        transform.position = startPosition + Vector3.left * newPosition;
    }
}
