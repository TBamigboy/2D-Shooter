using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScroll : MonoBehaviour
{
    public float scrollSpeed = 2f; // Speed at which the camera scrolls
    public float stopTime = 10f;   // Time (in seconds) when the camera will stop scrolling

    private float elapsedTime = 0f; // Keep track of how much time has passed

    void Update()
    {
        // Check if the elapsed time is less than the stopTime
        if (elapsedTime < stopTime)
        {
            // Move the camera to the right at the scroll speed
            transform.Translate(Vector3.right * scrollSpeed * Time.deltaTime);
            elapsedTime += Time.deltaTime; // Increment the time that has passed
        }
        else
        {
            // Stop scrolling when the time has been reached
            scrollSpeed = 0f;
        }
    }
}
