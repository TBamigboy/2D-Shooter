using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;  // Needed to handle scene loading

public class MainMenuManager : MonoBehaviour
{
    // Function to load the main game scene when "Play" is pressed
    public void LoadGameScene()
    {
        SceneManager.LoadScene("GameScene"); // Replace "GameScene" with the name of your main game scene
    }

    // Function to load the tutorial scene when "Tutorial" is pressed
    public void LoadTutorialScene()
    {
        SceneManager.LoadScene("Tutorial Level"); // Replace "TutorialScene" with your tutorial scene name
    }

    // Function to load credits scene or quit the game (optional)
    public void LoadCreditsScene()
    {
        SceneManager.LoadScene("CreditsScene"); // Replace with your actual credits scene, if you have one
    }

    // You can also add a quit function if needed
    public void QuitGame()
    {
        Debug.Log("Quit Game");
        Application.Quit();
    }
}
